package com.example.bmicalculatorapps

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var weightEditText: EditText
    private lateinit var heightEditText: EditText
    private lateinit var calculateButton: Button
    private lateinit var resultTextView: TextView

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        weightEditText = findViewById(R.id.weightEditText)
        heightEditText = findViewById(R.id.heightEditText)
        calculateButton = findViewById(R.id.calculateButton)
        resultTextView = findViewById(R.id.resultTextView)

        calculateButton.setOnClickListener {
            val weight = weightEditText.text.toString().toFloat()
            val height = heightEditText.text.toString().toFloat()

            val bmi = calculateBMI(weight, height)
            val statusBadan = statusBMI(weight, height)

            resultTextView.text = "Your BMI is $bmi $statusBadan"
        }
    }

    private fun calculateBMI(weight: Float, height: Float): Float {
        val bmi = weight / (height * height)
        return weight / (height/100 * height/100)
    }

    private fun statusBMI(weight: Float, height: Float): String {
        val statusBadan: String
        val bmi = weight / (height/100 * height/100)
        statusBadan = if (bmi <= 18.4) {
            "LOL, Anda seperti lidi"
        } else if (bmi >= 18.5 && bmi <= 24.9) {
            "Selamat, Anda Body Goals!"
        } else if (bmi >= 25 && bmi <= 29.9) {
            "Anda rada gendut."
        } else {
            "Anda FIX gendut."
        }
        return statusBadan
    }
}